// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// Never set ssr.external or resolve.external: the Worker has no runtime module resolution, so
// the build fails. Never add compression (compressPublicAssets, vite-plugin-compression):
// hosting already compresses at the edge.
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import type { Plugin } from "vite";
import { VitePWA, type VitePWAOptions } from "vite-plugin-pwa";

// The app shell is precached under this URL (not "/") so "/" navigations stay network-first.
const OFFLINE_SHELL_URL = "/?shell=offline";

const pwaOptions: Partial<VitePWAOptions> = {
  strategies: "generateSW",
  registerType: "autoUpdate",
  injectRegister: null,
  devOptions: { enabled: false },
  filename: "sw.js",
  // The manifest is a hand-written static file in public/manifest.webmanifest.
  manifest: false,
  includeAssets: ["favicon.ico", "apple-touch-icon.png", "icon-*.png", "shortcut-96.png", "manifest.webmanifest"],
  workbox: {
    globPatterns: ["**/*.{js,css,png,svg,ico,webmanifest}"],
    additionalManifestEntries: [{ url: OFFLINE_SHELL_URL, revision: Date.now().toString(36) }],
    navigateFallback: null,
    cleanupOutdatedCaches: true,
    clientsClaim: true,
    skipWaiting: true,
    runtimeCaching: [
      {
        urlPattern: ({ request, url }) =>
          request.mode === "navigate" && !url.pathname.startsWith("/~oauth"),
        handler: "NetworkFirst",
        options: {
          cacheName: "dark-days-pages",
          networkTimeoutSeconds: 3,
          precacheFallback: { fallbackURL: OFFLINE_SHELL_URL },
        },
      },
    ],
  },
};

// TanStack Start builds several Vite environments into separate folders. Point the service
// worker at the client (browser) output and generate it only for that environment.
const pwaClientOutDir: Plugin = {
  name: "dark-days:pwa-client-outdir",
  enforce: "pre",
  configResolved(config) {
    const outDir = config.environments?.["client"]?.build?.outDir;
    if (outDir) pwaOptions.outDir = outDir;
  },
};

const pwaPlugins = VitePWA(pwaOptions).map((plugin) =>
  plugin.name === "vite-plugin-pwa:build"
    ? { ...plugin, applyToEnvironment: (env: { name: string }) => env.name === "client" }
    : plugin,
);

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
    // "/" holds no per-user data (everything lives in localStorage), so it is prerendered to a
    // static index.html — portable to static hosting and APK wrappers.
    pages: [{ path: "/" }],
    prerender: { enabled: true, autoStaticPathsDiscovery: false },
  },
  plugins: [pwaClientOutDir, ...pwaPlugins],
});
