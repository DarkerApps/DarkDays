<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Zero network: no backend, auth, analytics, remote fonts or external URLs; all data lives in localStorage via `src/lib/refill.ts` (why: the app must work 100% offline and wrap into an APK).
- Day-count math for both modes ("since" / "till"), status thresholds, sorting, storage keys and the versioned JSON backup schema (which must keep importing older backups) live only in `src/lib/refill.ts` with tests in `src/lib/refill.test.ts` (why: one source of truth for countdown rules).
- Read localStorage and "today" only after mount (`useRefillStore`) (why: `/` is prerendered to a static `index.html`, so render must match the build-time HTML).
- Offline uses vite-plugin-pwa generateSW, registered only from `src/lib/pwa.ts`; vite.config targets the client environment's outDir and precaches the shell under `/?shell=offline` so `/` stays network-first (why: TanStack Start builds multiple environments; preview hosts must never get a worker).
- The web manifest is a hand-written static `public/manifest.webmanifest` with relative URLs (why: portable to static hosts and APK packaging).
