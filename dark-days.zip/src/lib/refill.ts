import { z } from "zod";

/** A local calendar date, always "YYYY-MM-DD". */
export type ISODate = string;

/**
 * "since" counts up from a start / last-done date, optionally against a target cycle.
 * "till" counts down to a target date (exams, deadlines).
 */
export type TrackMode = "since" | "till";

export type RefillItem = {
  id: string;
  name: string;
  tag?: string;
  mode: TrackMode;
  /** "since" only: expected cycle in days. Absent = open tracking with no target. */
  intervalDays?: number;
  /** "since": start / last-done date. "till": the day the item was set up. */
  lastRefilled: ISODate;
  /** "till" only: the date being counted down to. */
  targetDate?: ISODate;
  /** Reset / done dates, newest first ("since" items). Gaps between them are the logged intervals. */
  history: ISODate[];
  createdAt: string;
};

/** "neutral" = calm slate: open tracking, or a far-away target date. */
export type RefillStatus = "ok" | "low" | "due" | "neutral";

export type RefillComputed = {
  mode: TrackMode;
  daysSince: number;
  /** null for open "since" tracking (no target cycle). */
  daysRemaining: number | null;
  /** Next due date ("since" with a cycle) or target date ("till"). */
  nextDate: ISODate | null;
  /** 0 = just reset, 1 = due. null when there is no cycle to measure against. */
  progress: number | null;
  status: RefillStatus;
};

export type SortMode = "soonest" | "alpha";
export type FilterMode = "all" | "due";

export const HISTORY_LIMIT = 60;
export const STORAGE_KEY = "dark-days:v1";
/** Read once as a fallback so data saved under the app's previous name is kept. */
export const LEGACY_STORAGE_KEY = "dark-refill:v1";
/** A "till" target this close (in days) counts as coming up soon. */
export const TILL_SOON_DAYS = 7;

const DAY_MS = 86_400_000;

export function toISODate(d: Date): ISODate {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function todayISO(): ISODate {
  return toISODate(new Date());
}

function dayNumber(iso: ISODate): number {
  const [y, m, d] = iso.split("-").map(Number);
  return Math.round(Date.UTC(y ?? 1970, (m ?? 1) - 1, d ?? 1) / DAY_MS);
}

export function daysBetween(from: ISODate, to: ISODate): number {
  return dayNumber(to) - dayNumber(from);
}

export function addDays(iso: ISODate, days: number): ISODate {
  const d = new Date((dayNumber(iso) + days) * DAY_MS);
  return d.toISOString().slice(0, 10);
}

/** Days before the due date at which a cycled item counts as "running low". */
export function lowThreshold(intervalDays: number): number {
  return Math.max(3, Math.round(intervalDays * 0.2));
}

type ComputeInput = {
  mode?: TrackMode;
  intervalDays?: number;
  lastRefilled: ISODate;
  targetDate?: ISODate;
};

export function computeRefill(item: ComputeInput, today: ISODate): RefillComputed {
  if (item.mode === "till") {
    const target = item.targetDate ?? item.lastRefilled;
    const daysRemaining = daysBetween(today, target);
    const status: RefillStatus = daysRemaining <= 0 ? "due" : daysRemaining <= TILL_SOON_DAYS ? "low" : "neutral";
    return { mode: "till", daysSince: 0, daysRemaining, nextDate: target, progress: null, status };
  }

  const daysSince = Math.max(0, daysBetween(item.lastRefilled, today));
  if (!item.intervalDays) {
    return { mode: "since", daysSince, daysRemaining: null, nextDate: null, progress: null, status: "neutral" };
  }

  const daysRemaining = item.intervalDays - daysSince;
  const progress = Math.min(1, Math.max(0, daysSince / item.intervalDays));
  const status: RefillStatus =
    daysRemaining <= 0 ? "due" : daysRemaining <= lowThreshold(item.intervalDays) ? "low" : "ok";
  return {
    mode: "since",
    daysSince,
    daysRemaining,
    nextDate: addDays(item.lastRefilled, item.intervalDays),
    progress,
    status,
  };
}

export function isDueSoon(item: RefillItem, today: ISODate): boolean {
  const { status } = computeRefill(item, today);
  return status === "low" || status === "due";
}

/** Reset / done: today becomes the new start date and is logged in history once. */
export function logRefill(item: RefillItem, today: ISODate): RefillItem {
  const history = item.history[0] === today ? item.history : [today, ...item.history];
  return { ...item, lastRefilled: today, history: history.slice(0, HISTORY_LIMIT) };
}

export function undoLastRefill(item: RefillItem, previous: RefillItem): RefillItem {
  return { ...item, lastRefilled: previous.lastRefilled, history: previous.history };
}

/** Logged intervals in days between consecutive resets, newest first. */
export function intervals(history: ISODate[]): number[] {
  const out: number[] = [];
  for (let i = 0; i < history.length - 1; i++) out.push(daysBetween(history[i + 1]!, history[i]!));
  return out;
}

/** Average logged interval in whole days, or null with fewer than two log entries. */
export function averageInterval(history: ISODate[]): number | null {
  const gaps = intervals(history);
  if (gaps.length === 0) return null;
  return Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length);
}

const byName = (a: RefillItem, b: RefillItem) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" });

export function sortItems(items: RefillItem[], mode: SortMode, today: ISODate): RefillItem[] {
  const copy = [...items];
  if (mode === "alpha") return copy.sort(byName);
  return copy.sort((a, b) => {
    const ra = computeRefill(a, today);
    const rb = computeRefill(b, today);
    // Items with a countdown first (soonest first); open trackers after, longest elapsed first.
    if (ra.daysRemaining !== null && rb.daysRemaining !== null) {
      return ra.daysRemaining - rb.daysRemaining || byName(a, b);
    }
    if (ra.daysRemaining !== null) return -1;
    if (rb.daysRemaining !== null) return 1;
    return rb.daysSince - ra.daysSince || byName(a, b);
  });
}

export function mostUrgent(items: RefillItem[], today: ISODate, count = 3): RefillItem[] {
  return sortItems(items, "soonest", today).slice(0, count);
}

export function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export type ItemDraft = {
  name: string;
  tag: string;
  mode: TrackMode;
  /** "since": cycle in days, or null for no target. Ignored for "till". */
  intervalDays: number | null;
  /** "since": start / last date. "till": set-up date (usually today). */
  lastRefilled: ISODate;
  /** "till": target date. Ignored for "since". */
  targetDate: ISODate | null;
};

export function createItem(draft: ItemDraft): RefillItem {
  const tag = draft.tag.trim();
  const base = {
    id: newId(),
    name: draft.name.trim(),
    ...(tag ? { tag } : {}),
    lastRefilled: draft.lastRefilled,
    createdAt: new Date().toISOString(),
  };
  if (draft.mode === "till") {
    return { ...base, mode: "till", targetDate: draft.targetDate ?? draft.lastRefilled, history: [] };
  }
  return {
    ...base,
    mode: "since",
    ...(draft.intervalDays ? { intervalDays: draft.intervalDays } : {}),
    history: [draft.lastRefilled],
  };
}

export function applyDraft(item: RefillItem, draft: ItemDraft): RefillItem {
  const tag = draft.tag.trim();
  const { tag: _tag, intervalDays: _interval, targetDate: _target, ...rest } = item;
  const common = { ...rest, ...(tag ? { tag } : {}), name: draft.name.trim() };

  if (draft.mode === "till") {
    // Keeps the "since" log intact in case the item is switched back later.
    return { ...common, mode: "till", targetDate: draft.targetDate ?? item.targetDate ?? item.lastRefilled };
  }

  let history = item.history;
  if (history.length === 0) history = [draft.lastRefilled];
  else if (draft.lastRefilled !== item.lastRefilled && !history.includes(draft.lastRefilled)) {
    history = [draft.lastRefilled, ...history].sort().reverse().slice(0, HISTORY_LIMIT);
  }
  return {
    ...common,
    mode: "since",
    ...(draft.intervalDays ? { intervalDays: draft.intervalDays } : {}),
    lastRefilled: draft.lastRefilled,
    history,
  };
}

/* ---------- Backup format ---------- */

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

const itemSchema = z
  .object({
    id: z.string().min(1),
    name: z.string().trim().min(1).max(80),
    tag: z.string().trim().max(24).optional(),
    mode: z.enum(["since", "till"]).optional(),
    intervalDays: z.number().int().min(1).max(3650).nullable().optional(),
    lastRefilled: isoDate,
    targetDate: isoDate.nullable().optional(),
    history: z.array(isoDate).optional(),
    createdAt: z.string().optional(),
  })
  .refine((i) => i.mode !== "till" || !!i.targetDate, { message: "A days-till item needs a target date" });

const backupSchema = z.union([
  z.object({ app: z.enum(["dark-days", "dark-refill"]), version: z.number(), items: z.array(itemSchema) }),
  z.array(itemSchema),
]);

export type Backup = {
  app: "dark-days";
  version: 2;
  exportedAt: string;
  items: RefillItem[];
};

export function buildBackup(items: RefillItem[]): Backup {
  return { app: "dark-days", version: 2, exportedAt: new Date().toISOString(), items };
}

/** Accepts current backups and older Dark Refill files (no mode = "since" with a cycle). */
export function parseBackup(raw: unknown): RefillItem[] {
  const parsed = backupSchema.parse(raw);
  const list = Array.isArray(parsed) ? parsed : parsed.items;
  return list.map((i): RefillItem => {
    const tag = i.tag?.trim();
    const base = {
      id: i.id,
      name: i.name,
      ...(tag ? { tag } : {}),
      lastRefilled: i.lastRefilled,
      createdAt: i.createdAt ?? new Date().toISOString(),
    };
    if (i.mode === "till") {
      return { ...base, mode: "till", targetDate: i.targetDate!, history: (i.history ?? []).slice(0, HISTORY_LIMIT) };
    }
    return {
      ...base,
      mode: "since",
      ...(i.intervalDays ? { intervalDays: i.intervalDays } : {}),
      history: (i.history && i.history.length > 0 ? i.history : [i.lastRefilled]).slice(0, HISTORY_LIMIT),
    };
  });
}

export function loadItems(): RefillItem[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY) ?? window.localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!raw) return [];
    return parseBackup(JSON.parse(raw));
  } catch {
    return [];
  }
}

export function saveItems(items: RefillItem[]): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(buildBackup(items)));
  } catch {
    /* storage full or blocked — nothing else we can do offline */
  }
}
