import { describe, expect, it } from "vitest";
import {
  applyDraft,
  averageInterval,
  computeRefill,
  createItem,
  isDueSoon,
  logRefill,
  mostUrgent,
  parseBackup,
  sortItems,
  buildBackup,
  type RefillItem,
} from "./refill";

function item(name: string, intervalDays: number | null, lastRefilled: string): RefillItem {
  return createItem({ name, tag: "", mode: "since", intervalDays, lastRefilled, targetDate: null });
}

function till(name: string, targetDate: string): RefillItem {
  return createItem({ name, tag: "", mode: "till", intervalDays: null, lastRefilled: "2026-11-01", targetDate });
}

describe("days since with a target cycle", () => {
  it("counts days since and days remaining for a 30-day cycle", () => {
    const r = computeRefill({ intervalDays: 30, lastRefilled: "2026-11-01" }, "2026-11-21");
    expect(r.daysSince).toBe(20);
    expect(r.daysRemaining).toBe(10);
    expect(r.nextDate).toBe("2026-12-01");
    expect(r.status).toBe("ok");
  });

  it("marks an item as running low inside the last fifth of its cycle", () => {
    expect(computeRefill({ intervalDays: 30, lastRefilled: "2026-11-01" }, "2026-11-25").status).toBe("low");
  });

  it("marks an item due on the due date and overdue after it", () => {
    expect(computeRefill({ intervalDays: 15, lastRefilled: "2026-11-01" }, "2026-11-16").status).toBe("due");
    const late = computeRefill({ intervalDays: 15, lastRefilled: "2026-11-01" }, "2026-11-20");
    expect(late.daysRemaining).toBe(-4);
    expect(late.status).toBe("due");
  });

  it("handles month and DST boundaries without off-by-one", () => {
    expect(computeRefill({ intervalDays: 45, lastRefilled: "2026-10-20" }, "2026-11-03").daysSince).toBe(14);
  });
});

describe("days since with no target", () => {
  it("shows elapsed days only, in neutral, never overdue", () => {
    const r = computeRefill(item("Gas", null, "2026-11-07"), "2027-03-01");
    expect(r.daysSince).toBe(114);
    expect(r.daysRemaining).toBeNull();
    expect(r.progress).toBeNull();
    expect(r.status).toBe("neutral");
    expect(isDueSoon(item("Gas", null, "2025-01-01"), "2027-03-01")).toBe(false);
  });

  it("logs each reset so the actual intervals can be averaged", () => {
    let gas = item("Gas", null, "2026-10-01");
    gas = logRefill(gas, "2026-10-15");
    gas = logRefill(gas, "2026-11-01");
    expect(gas.history).toEqual(["2026-11-01", "2026-10-15", "2026-10-01"]);
    expect(averageInterval(gas.history)).toBe(16); // (14 + 17) / 2 = 15.5 → 16
  });
});

describe("days till", () => {
  it("counts remaining days to the target date", () => {
    const r = computeRefill(till("Exam", "2026-12-15"), "2026-11-21");
    expect(r.daysRemaining).toBe(24);
    expect(r.status).toBe("neutral");
  });

  it("is coming up within 7 days and due on or after the date", () => {
    expect(computeRefill(till("Exam", "2026-11-28"), "2026-11-21").status).toBe("low");
    expect(computeRefill(till("Exam", "2026-11-21"), "2026-11-21").status).toBe("due");
    expect(computeRefill(till("Exam", "2026-11-19"), "2026-11-21").daysRemaining).toBe(-2);
  });

  it("switching an item to days till keeps its since log", () => {
    const a = logRefill(item("Pens", 30, "2026-10-01"), "2026-11-01");
    const t = applyDraft(a, { name: "Pens", tag: "", mode: "till", intervalDays: null, lastRefilled: "2026-11-01", targetDate: "2026-12-01" });
    expect(t.mode).toBe("till");
    expect(t.targetDate).toBe("2026-12-01");
    expect(t.intervalDays).toBeUndefined();
    expect(t.history).toEqual(["2026-11-01", "2026-10-01"]);
  });
});

describe("reset button", () => {
  it("sets the start date to today and adds today to history once", () => {
    const a = item("Coffee", 30, "2026-10-01");
    const once = logRefill(a, "2026-11-21");
    expect(once.lastRefilled).toBe("2026-11-21");
    expect(once.history).toEqual(["2026-11-21", "2026-10-01"]);
    expect(logRefill(once, "2026-11-21").history).toEqual(["2026-11-21", "2026-10-01"]);
  });
});

describe("sorting and widget", () => {
  const items = [
    item("Zinc", 30, "2026-11-20"),
    item("Apples", 15, "2026-11-01"),
    item("Milk", 7, "2026-11-18"),
    item("Ink", 45, "2026-10-01"),
    item("Oil", null, "2026-09-01"),
    till("Exam", "2026-11-23"),
  ];

  it("sorts soonest first, open trackers last", () => {
    expect(sortItems(items, "soonest", "2026-11-21").map((i) => i.name)).toEqual(["Ink", "Apples", "Exam", "Milk", "Zinc", "Oil"]);
  });

  it("sorts alphabetically", () => {
    expect(sortItems(items, "alpha", "2026-11-21").map((i) => i.name)).toEqual(["Apples", "Exam", "Ink", "Milk", "Oil", "Zinc"]);
  });

  it("widget shows the 3 most urgent items", () => {
    expect(mostUrgent(items, "2026-11-21").map((i) => i.name)).toEqual(["Ink", "Apples", "Exam"]);
  });
});

describe("json backup", () => {
  it("round-trips all three kinds of item through export and import", () => {
    const items = [item("Pens", 60, "2026-09-01"), item("Oil", null, "2026-09-01"), till("Exam", "2027-01-10")];
    const json = JSON.parse(JSON.stringify(buildBackup(items)));
    expect(json.app).toBe("dark-days");
    expect(parseBackup(json)).toEqual(items);
  });

  it("imports an older Dark Refill backup as days-since items", () => {
    const old = { app: "dark-refill", version: 1, items: [{ id: "a", name: "Soap", intervalDays: 30, lastRefilled: "2026-11-01", history: ["2026-11-01"] }] };
    const [soap] = parseBackup(old);
    expect(soap?.mode).toBe("since");
    expect(soap?.intervalDays).toBe(30);
  });

  it("rejects a file that is not a backup, or a days-till item without a date", () => {
    expect(() => parseBackup({ hello: "world" })).toThrow();
    expect(() => parseBackup([{ id: "x", name: "Exam", mode: "till", lastRefilled: "2026-11-01" }])).toThrow();
  });
});
