/// <reference types="vite-plugin-pwa/client" />
// The only place the offline service worker is registered. Never registers in dev,
// inside iframes, or on Lovable preview hosts; unregisters stale workers there instead.

const SW_PATH = "/sw.js";

function isPreviewHost(hostname: string): boolean {
  if (/\.(lovable\.app|gpt-eng\.com|gptengineer\.run)$/.test(hostname)) {
    const label = hostname.split(".")[0] ?? "";
    if (/^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/.test(label)) return true;
    if (/^project--[^.]+-dev$/.test(label)) return true;
  }
  return (
    hostname === "lovableproject.com" ||
    hostname.endsWith(".lovableproject.com") ||
    hostname === "lovableproject-dev.com" ||
    hostname.endsWith(".lovableproject-dev.com") ||
    hostname === "beta.lovable.dev" ||
    hostname.endsWith(".beta.lovable.dev")
  );
}

function inIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

async function unregisterAppWorkers(): Promise<void> {
  const regs = await navigator.serviceWorker.getRegistrations();
  await Promise.allSettled(
    regs
      .filter((r) => {
        const url = r.active?.scriptURL ?? r.waiting?.scriptURL ?? r.installing?.scriptURL ?? "";
        return url && new URL(url).pathname === SW_PATH;
      })
      .map((r) => r.unregister()),
  );
}

export async function setupOfflineSupport(): Promise<void> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
  const hostname = window.location.hostname.toLowerCase();
  const killSwitch = new URLSearchParams(window.location.search).get("sw") === "off";

  if (!import.meta.env.PROD || inIframe() || isPreviewHost(hostname) || killSwitch) {
    await unregisterAppWorkers().catch(() => {});
    return;
  }

  const { registerSW } = await import("virtual:pwa-register");
  registerSW({ immediate: true });
}
