import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { ArrowDownUp, Download, LayoutGrid, List, MoreHorizontal, Plus, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ItemDialog } from "@/components/refill/ItemDialog";
import { ItemRow } from "@/components/refill/ItemRow";
import { WidgetCard } from "@/components/refill/WidgetCard";
import { formatDate } from "@/components/refill/status";
import { useRefillStore } from "@/hooks/use-refill-store";
import { cn } from "@/lib/utils";
import { buildBackup, daysBetween, isDueSoon, parseBackup, sortItems, type FilterMode, type RefillItem, type SortMode } from "@/lib/refill";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dark Days — offline days since & days till" },
      { name: "description", content: "Count days since refills, habits and last-done events, or days till exams and deadlines. Pure-black, fully offline, no account." },
      { property: "og:title", content: "Dark Days — offline days since & days till" },
      { property: "og:description", content: "Days since you refilled, days till your exam. Pure-black, private, works without internet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

type ViewMode = "list" | "widget";
const PREFS_KEY = "dark-days:prefs";

function Index() {
  const store = useRefillStore();
  const { items, ready, today } = store;
  const [filter, setFilter] = useState<FilterMode>("all");
  const [sort, setSort] = useState<SortMode>("soonest");
  const [view, setView] = useState<ViewMode>("list");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<RefillItem | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [undoable, setUndoable] = useState<Record<string, RefillItem>>({});
  const undoTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  useEffect(() => () => Object.values(undoTimers.current).forEach(clearTimeout), []);

  function clearUndo(id: string) {
    clearTimeout(undoTimers.current[id]);
    delete undoTimers.current[id];
    setUndoable((u) => {
      const { [id]: _drop, ...rest } = u;
      return rest;
    });
  }

  function handleUndo(item: RefillItem) {
    const previous = undoable[item.id];
    if (previous) store.restore(previous);
    clearUndo(item.id);
  }

  // Restore prefs and handle home-screen shortcut URLs.
  useEffect(() => {
    try {
      const prefs = JSON.parse(localStorage.getItem(PREFS_KEY) ?? "{}") as { sort?: SortMode; view?: ViewMode };
      if (prefs.sort === "alpha" || prefs.sort === "soonest") setSort(prefs.sort);
      if (prefs.view === "list" || prefs.view === "widget") setView(prefs.view);
    } catch {
      /* ignore */
    }
    const params = new URLSearchParams(window.location.search);
    if (params.get("filter") === "due") {
      setFilter("due");
      setView("list");
    }
    if (params.get("view") === "widget") setView("widget");
    if (params.get("action") === "add") {
      setEditing(null);
      setDialogOpen(true);
    }
    if (params.has("filter") || params.has("view") || params.has("action") || params.has("shell")) {
      window.history.replaceState(null, "", window.location.pathname);
    }
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(PREFS_KEY, JSON.stringify({ sort, view }));
  }, [sort, view, ready]);

  const dueCount = useMemo(() => (today ? items.filter((i) => isDueSoon(i, today)).length : 0), [items, today]);
  const visible = useMemo(() => {
    if (!today) return [];
    const base = filter === "due" ? items.filter((i) => isDueSoon(i, today)) : items;
    return sortItems(base, sort, today);
  }, [items, filter, sort, today]);

  function openNew() {
    setEditing(null);
    setDialogOpen(true);
  }

  function handleRefill(item: RefillItem) {
    const previous = item;
    const gap = today ? daysBetween(item.lastRefilled, today) : 0;
    store.refill(item.id);
    clearTimeout(undoTimers.current[item.id]);
    setUndoable((u) => ({ ...u, [item.id]: previous }));
    undoTimers.current[item.id] = setTimeout(() => clearUndo(item.id), 60_000);
    toast(`${item.name} reset`, {
      description: `Logged ${gap} day${gap === 1 ? "" : "s"}. Undo available for 1 minute.`,
    });
  }

  function handleExport() {
    const blob = new Blob([JSON.stringify(buildBackup(items), null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `dark-days-backup-${today || "export"}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Backup exported", { description: `${items.length} item${items.length === 1 ? "" : "s"} saved to a .json file.` });
  }

  async function handleImport(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const imported = parseBackup(JSON.parse(await file.text()));
      if (items.length > 0 && !window.confirm(`Replace your ${items.length} current item(s) with ${imported.length} from the backup?`)) return;
      store.replaceAll(imported);
      toast("Backup imported", { description: `${imported.length} item${imported.length === 1 ? "" : "s"} restored.` });
    } catch {
      toast.error("That file isn't a Dark Days backup.");
    }
  }

  return (
    <div className="mx-auto min-h-dvh max-w-xl px-5 pb-32 pt-[max(env(safe-area-inset-top),1.75rem)]">
      <header className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-xl font-medium tracking-tight text-foreground">Dark Days</h1>
          <p className="num mt-1 text-xs text-muted-foreground">
            {today ? formatDate(today, { weekday: "long", month: "long", day: "numeric" }) : "\u00a0"}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setView(view === "widget" ? "list" : "widget")}
            aria-label={view === "widget" ? "Show full list" : "Show widget view"}
            className="grid size-10 place-items-center rounded-full text-muted-foreground transition-colors hover:text-foreground"
          >
            {view === "widget" ? <List className="size-[18px]" /> : <LayoutGrid className="size-[18px]" />}
          </button>
          <DropdownMenu>
            <DropdownMenuTrigger
              aria-label="Backup options"
              className="grid size-10 place-items-center rounded-full text-muted-foreground outline-none transition-colors hover:text-foreground"
            >
              <MoreHorizontal className="size-[18px]" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52 border-border bg-popover shadow-none">
              <DropdownMenuItem onSelect={handleExport} disabled={items.length === 0}>
                <Download className="size-4" /> Export backup (.json)
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => fileRef.current?.click()}>
                <Upload className="size-4" /> Import backup
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <div className="px-2 py-1.5 text-[11px] leading-snug text-muted-foreground">Data stays on this device. Nothing is uploaded.</div>
            </DropdownMenuContent>
          </DropdownMenu>
          <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={handleImport} />
        </div>
      </header>

      {!ready ? null : view === "widget" ? (
        <div className="flex min-h-[60dvh] flex-col justify-center">
          <WidgetCard items={items} today={today} onRefill={handleRefill} size="large" />
          <p className="mt-4 text-center text-[11px] text-muted-foreground">Widget view · three most urgent</p>
        </div>
      ) : (
        <>
          {items.length > 0 && <WidgetCard items={items} today={today} onRefill={handleRefill} />}

          <div className="mb-4 mt-8 flex items-center justify-between">
            <div role="tablist" aria-label="Filter items" className="flex gap-1 rounded-full border border-border p-1">
              {(
                [
                  ["all", "All", items.length],
                  ["due", "Due soon", dueCount],
                ] as const
              ).map(([key, label, count]) => (
                <button
                  key={key}
                  role="tab"
                  aria-selected={filter === key}
                  onClick={() => setFilter(key)}
                  className={cn(
                    "flex h-8 items-center gap-1.5 rounded-full px-3.5 text-xs transition-colors",
                    filter === key ? "bg-accent text-foreground" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {label}
                  <span className={cn("num", key === "due" && count > 0 ? "text-status-low" : "text-muted-foreground")}>{count}</span>
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setSort(sort === "soonest" ? "alpha" : "soonest")}
              className="flex h-8 items-center gap-1.5 rounded-full px-3 text-xs text-muted-foreground transition-colors hover:text-foreground"
              aria-label={`Sort: ${sort === "soonest" ? "Soonest first" : "Alphabetical"}. Tap to change.`}
            >
              <ArrowDownUp className="size-3.5" />
              {sort === "soonest" ? "Soonest" : "A–Z"}
            </button>
          </div>

          {items.length === 0 ? (
            <EmptyState onAdd={openNew} />
          ) : visible.length === 0 ? (
            <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
              Nothing coming up. All calm.
            </p>
          ) : (
            <ul className="space-y-2.5">
              {visible.map((item) => (
                <ItemRow
                  key={item.id}
                  item={item}
                  today={today}
                  onRefill={handleRefill}
                  canUndo={item.id in undoable}
                  onUndo={handleUndo}
                  onOpen={(i) => {
                    setEditing(i);
                    setDialogOpen(true);
                  }}
                />
              ))}
            </ul>
          )}
        </>
      )}

      <div className="pointer-events-none fixed inset-x-0 bottom-0 flex justify-center border-t border-border bg-background px-5 pb-[max(env(safe-area-inset-bottom),1rem)] pt-3">
        <button
          type="button"
          onClick={openNew}
          className="pointer-events-auto flex h-12 w-full max-w-xl items-center justify-center gap-2 rounded-full border border-border bg-surface text-sm text-foreground transition-colors hover:border-ring active:bg-accent"
        >
          <Plus className="size-4" /> Add item
        </button>
      </div>

      <ItemDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        item={editing}
        today={today}
        onSave={(draft) => {
          if (editing) store.update(editing.id, draft);
          else store.add(draft);
        }}
        onDelete={(item) => {
          store.remove(item.id);
          toast(`${item.name} deleted`);
        }}
      />
    </div>
  );
}

function EmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="rounded-2xl border border-border bg-card px-6 py-12 text-center">
      <div className="mx-auto mb-5 size-12 rounded-full border-2 border-border border-t-status-ok" aria-hidden />
      <h2 className="text-base text-foreground">Count the days</h2>
      <p className="mx-auto mt-2 max-w-xs text-sm text-muted-foreground">
        Days since you refilled coffee or watered plants, or days till your exam. Tap Reset when you do it again and the interval is logged.
      </p>
      <button type="button" onClick={onAdd} className="mt-6 h-10 rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground">
        Add your first item
      </button>
    </div>
  );
}
