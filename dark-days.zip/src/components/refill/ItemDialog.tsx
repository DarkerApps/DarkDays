import { useEffect, useState, type FormEvent } from "react";
import { Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { averageInterval, daysBetween, type ISODate, type ItemDraft, type RefillItem, type TrackMode } from "@/lib/refill";
import { formatDate } from "./status";

const PRESETS = [7, 15, 30, 45, 60, 90];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

const MODES: { key: TrackMode; label: string; hint: string }[] = [
  { key: "since", label: "Days since", hint: "Count up from the last time — refills, habits, last-done events." },
  { key: "till", label: "Days till", hint: "Count down to a date — exams, deadlines, targets." },
];

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: RefillItem | null;
  today: ISODate;
  onSave: (draft: ItemDraft) => void;
  onDelete: (item: RefillItem) => void;
};

const fieldClass =
  "h-11 w-full rounded-lg border border-input bg-background px-3 text-[15px] text-foreground placeholder:text-muted-foreground/60 focus:border-ring focus:outline-none";
const labelClass = "mb-1.5 block text-[11px] uppercase tracking-[0.14em] text-muted-foreground";
const pillClass = (active: boolean) =>
  cn(
    "num h-8 rounded-md border px-3 text-xs transition-colors",
    active ? "border-ring bg-accent text-foreground" : "border-border text-muted-foreground hover:text-foreground",
  );

export function ItemDialog({ open, onOpenChange, item, today, onSave, onDelete }: Props) {
  const [mode, setMode] = useState<TrackMode>("since");
  const [name, setName] = useState("");
  const [tag, setTag] = useState("");
  const [interval, setInterval] = useState("");
  const [last, setLast] = useState(today);
  const [target, setTarget] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (!open) return;
    setMode(item?.mode ?? "since");
    setName(item?.name ?? "");
    setTag(item?.tag ?? "");
    setInterval(item?.intervalDays ? String(item.intervalDays) : "");
    setLast(item?.lastRefilled ?? today);
    setTarget(item?.targetDate ?? "");
  }, [open, item, today]);

  const noTarget = interval.trim() === "";
  const intervalNum = Number(interval);
  const intervalOk = noTarget || (Number.isInteger(intervalNum) && intervalNum >= 1 && intervalNum <= 3650);
  const valid =
    name.trim().length > 0 && (mode === "since" ? intervalOk && DATE_RE.test(last) : DATE_RE.test(target));
  const targetIn = DATE_RE.test(target) && today ? daysBetween(today, target) : null;
  const avg = item ? averageInterval(item.history) : null;

  function submit(e: FormEvent) {
    e.preventDefault();
    if (!valid) return;
    onSave({
      name: name.trim(),
      tag: tag.trim(),
      mode,
      intervalDays: mode === "since" && !noTarget ? intervalNum : null,
      lastRefilled: mode === "since" ? (last > today ? today : last) : (item?.lastRefilled ?? today),
      targetDate: mode === "till" ? target : null,
    });
    onOpenChange(false);
  }

  const hint = MODES.find((m) => m.key === mode)?.hint ?? "";

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto rounded-2xl border-border bg-card shadow-none sm:max-w-md">
          <DialogHeader className="text-left">
            <DialogTitle className="text-base font-medium">{item ? "Edit item" : "New item"}</DialogTitle>
            <DialogDescription className="sr-only">{hint}</DialogDescription>
          </DialogHeader>

          <form onSubmit={submit} className="space-y-5">
            <div>
              <div role="radiogroup" aria-label="Counting mode" className="grid grid-cols-2 gap-1 rounded-full border border-border bg-background p-1">
                {MODES.map((m) => (
                  <button
                    key={m.key}
                    type="button"
                    role="radio"
                    aria-checked={mode === m.key}
                    onClick={() => setMode(m.key)}
                    className={cn(
                      "h-9 rounded-full text-sm transition-colors",
                      mode === m.key ? "bg-accent text-foreground" : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
              <p className="mt-2 px-1 text-[11px] leading-snug text-muted-foreground">{hint}</p>
            </div>

            <div>
              <label htmlFor="item-name" className={labelClass}>Name</label>
              <input
                id="item-name"
                className={fieldClass}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={mode === "since" ? "Dish soap" : "Physics exam"}
                maxLength={80}
                required
              />
            </div>
            <div>
              <label htmlFor="item-tag" className={labelClass}>Tag <span className="normal-case tracking-normal">(optional)</span></label>
              <input id="item-tag" className={fieldClass} value={tag} onChange={(e) => setTag(e.target.value)} placeholder={mode === "since" ? "Kitchen" : "Study"} maxLength={24} />
            </div>

            {mode === "since" ? (
              <>
                <div>
                  <label htmlFor="item-last" className={labelClass}>Start / last date</label>
                  <input id="item-last" type="date" className={cn(fieldClass, "num")} value={last} max={today} onChange={(e) => setLast(e.target.value)} required />
                </div>
                <div>
                  <label htmlFor="item-interval" className={labelClass}>
                    Expected cycle <span className="normal-case tracking-normal">(optional)</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      id="item-interval"
                      className={cn(fieldClass, "num w-24")}
                      inputMode="numeric"
                      type="number"
                      min={1}
                      max={3650}
                      value={interval}
                      placeholder="—"
                      onChange={(e) => setInterval(e.target.value)}
                    />
                    <span className="text-sm text-muted-foreground">days</span>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <button type="button" onClick={() => setInterval("")} className={pillClass(noTarget)} aria-pressed={noTarget}>
                      No target
                    </button>
                    {PRESETS.map((p) => (
                      <button key={p} type="button" onClick={() => setInterval(String(p))} className={pillClass(intervalNum === p)} aria-pressed={intervalNum === p}>
                        {p}d
                      </button>
                    ))}
                  </div>
                  {noTarget && <p className="mt-2 px-1 text-[11px] text-muted-foreground">Just counts the days. No due date, no warnings.</p>}
                </div>
              </>
            ) : (
              <div>
                <label htmlFor="item-target" className={labelClass}>Target date</label>
                <input id="item-target" type="date" className={cn(fieldClass, "num")} value={target} onChange={(e) => setTarget(e.target.value)} required />
                {targetIn !== null && (
                  <p className="num mt-2 px-1 text-[11px] text-muted-foreground">
                    {targetIn === 0 ? "That's today." : targetIn > 0 ? `${targetIn}d from today.` : `${-targetIn}d ago.`}
                  </p>
                )}
              </div>
            )}

            {mode === "since" && item && item.history.length > 0 && (
              <div>
                <div className="flex items-baseline justify-between">
                  <span className={labelClass}>Log</span>
                  {avg !== null && <span className="num text-[11px] text-muted-foreground">avg {avg}d</span>}
                </div>
                <ol className="max-h-40 overflow-y-auto rounded-lg border border-border">
                  {item.history.map((d, idx) => {
                    const gap = item.history[idx + 1] ? daysBetween(item.history[idx + 1]!, d) : null;
                    return (
                      <li key={d} className="num flex justify-between border-b border-border px-3 py-2 text-xs last:border-b-0">
                        <span className="text-foreground">{formatDate(d, { year: "numeric", month: "short", day: "numeric" })}</span>
                        <span className="text-muted-foreground">{gap !== null ? `${gap}d` : "start"}</span>
                      </li>
                    );
                  })}
                </ol>
              </div>
            )}

            <div className="flex items-center gap-2 pt-1">
              {item && (
                <button
                  type="button"
                  onClick={() => setConfirmDelete(true)}
                  aria-label="Delete item"
                  className="grid size-11 place-items-center rounded-lg border border-border text-status-due transition-colors hover:border-status-due"
                >
                  <Trash2 className="size-4" />
                </button>
              )}
              <button
                type="submit"
                disabled={!valid}
                className="h-11 flex-1 rounded-lg bg-primary text-sm font-medium text-primary-foreground transition-opacity disabled:opacity-40"
              >
                {item ? "Save changes" : "Add item"}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent className="rounded-2xl border-border bg-card shadow-none">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base font-medium">Delete {item?.name}?</AlertDialogTitle>
            <AlertDialogDescription>It and its log will be removed from this device.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border bg-transparent shadow-none">Keep</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground shadow-none hover:bg-destructive/90"
              onClick={() => {
                if (item) onDelete(item);
                onOpenChange(false);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
