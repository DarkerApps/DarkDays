import { RotateCw, Undo2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { computeRefill, type ISODate, type RefillItem } from "@/lib/refill";
import { ProgressTrack, StatusDot, countLabel, metaLine, statusText } from "./status";

type Props = {
  item: RefillItem;
  today: ISODate;
  onRefill: (item: RefillItem) => void;
  onOpen: (item: RefillItem) => void;
  canUndo?: boolean;
  onUndo?: (item: RefillItem) => void;
};

export function ItemRow({ item, today, onRefill, onOpen, canUndo = false, onUndo }: Props) {
  const r = computeRefill(item, today);
  const label = countLabel(r);
  const canReset = item.mode === "since";

  return (
    <li className="rounded-xl border border-border bg-card">
      <button
        type="button"
        onClick={() => onOpen(item)}
        className="block w-full px-4 pb-3 pt-4 text-left"
        aria-label={`Edit ${item.name}`}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <StatusDot status={r.status} />
              <span className="truncate text-[15px] text-foreground">{item.name}</span>
            </div>
            {item.tag && (
              <span className="ml-3.5 mt-1 inline-block text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                {item.tag}
              </span>
            )}
          </div>
          <div className="shrink-0 text-right leading-none">
            <span className={cn("num text-2xl font-light", statusText[r.status])}>{label.value}</span>
            <div className="mt-1 text-[10px] text-muted-foreground">{label.unit}</div>
          </div>
        </div>
        {r.progress !== null && <ProgressTrack progress={r.progress} status={r.status} className="mt-3" />}
      </button>
      <div className="flex min-h-[3.25rem] items-center justify-between gap-3 border-t border-border py-2 pl-4 pr-2">
        <span className="num truncate text-[11px] text-muted-foreground">{metaLine(item, r)}</span>
        {canReset && (
          <button
            type="button"
            onClick={() => (canUndo && onUndo ? onUndo(item) : onRefill(item))}
            className="flex h-9 shrink-0 items-center gap-1.5 rounded-lg border border-border px-3 text-xs text-foreground transition-colors hover:border-ring active:bg-accent"
          >
            {canUndo ? <Undo2 className="size-3.5" /> : <RotateCw className="size-3.5" />}
            {canUndo ? "Undo" : "Reset"}
          </button>
        )}
      </div>
    </li>
  );
}
