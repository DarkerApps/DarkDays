import { cn } from "@/lib/utils";
import { averageInterval, type RefillComputed, type RefillItem, type RefillStatus } from "@/lib/refill";

export const statusText: Record<RefillStatus, string> = {
  ok: "text-status-ok",
  low: "text-status-low",
  due: "text-status-due",
  neutral: "text-status-neutral",
};

const statusBg: Record<RefillStatus, string> = {
  ok: "bg-status-ok",
  low: "bg-status-low",
  due: "bg-status-due",
  neutral: "bg-status-neutral",
};

/** Big number + small unit shown on cards: "24 days left", "14 days since", "3 days over". */
export function countLabel(r: RefillComputed): { value: string; unit: string } {
  if (r.daysRemaining === null) return { value: String(r.daysSince), unit: r.daysSince === 1 ? "day since" : "days since" };
  const d = r.daysRemaining;
  const till = r.mode === "till";
  if (d === 0) return { value: "0", unit: till ? "today" : "due today" };
  if (d < 0) {
    const n = -d;
    return { value: String(n), unit: till ? (n === 1 ? "day ago" : "days ago") : n === 1 ? "day over" : "days over" };
  }
  return { value: String(d), unit: d === 1 ? "day left" : "days left" };
}

/** One quiet line of context under a card. */
export function metaLine(item: RefillItem, r: RefillComputed): string {
  if (r.mode === "till") {
    return `Target ${formatDate(r.nextDate ?? item.lastRefilled, { weekday: "short", month: "short", day: "numeric", year: "numeric" })}`;
  }
  const since = r.daysSince === 0 ? "Reset today" : `${r.daysSince}d since`;
  if (item.intervalDays && r.nextDate) return `${since} · every ${item.intervalDays}d · next ${formatDate(r.nextDate)}`;
  const avg = averageInterval(item.history);
  return `Since ${formatDate(item.lastRefilled)}${avg !== null ? ` · avg ${avg}d` : ""}`;
}

export function StatusDot({ status, className }: { status: RefillStatus; className?: string }) {
  return <span aria-hidden className={cn("inline-block size-1.5 shrink-0 rounded-full", statusBg[status], className)} />;
}

export function ProgressTrack({ progress, status, className }: { progress: number; status: RefillStatus; className?: string }) {
  return (
    <div
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(progress * 100)}
      aria-label="Cycle used"
      className={cn("h-[3px] w-full overflow-hidden rounded-full bg-track", className)}
    >
      <div className={cn("h-full rounded-full transition-[width] duration-500", statusBg[status])} style={{ width: `${Math.max(2, progress * 100)}%` }} />
    </div>
  );
}

export function formatDate(iso: string, opts: Intl.DateTimeFormatOptions = { month: "short", day: "numeric" }): string {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1).toLocaleDateString(undefined, opts);
}
