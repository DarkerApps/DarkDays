import { cn } from "@/lib/utils";
import { computeRefill, mostUrgent, type ISODate, type RefillItem } from "@/lib/refill";
import { ProgressTrack, StatusDot, countLabel, statusText } from "./status";

type Props = {
  items: RefillItem[];
  today: ISODate;
  onRefill: (item: RefillItem) => void;
  size?: "compact" | "large";
};

export function WidgetCard({ items, today, onRefill, size = "compact" }: Props) {
  const urgent = mostUrgent(items, today, 3);
  const large = size === "large";

  return (
    <section
      aria-label="Widget view: most urgent items"
      className={cn("rounded-2xl border border-border bg-background", large ? "p-6" : "p-4")}
    >
      <header className="mb-3 flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Next up</span>
        <span className="num text-[11px] text-muted-foreground">{items.length} tracked</span>
      </header>

      {urgent.length === 0 ? (
        <p className="py-4 text-sm text-muted-foreground">Nothing tracked yet.</p>
      ) : (
        <ul className={cn("divide-y divide-border", large && "space-y-1")}>
          {urgent.map((item) => {
            const r = computeRefill(item, today);
            const label = countLabel(r);
            return (
              <li key={item.id} className={cn("flex items-center gap-3", large ? "py-4" : "py-2.5")}>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <StatusDot status={r.status} />
                    <span className={cn("truncate text-foreground", large ? "text-base" : "text-sm")}>{item.name}</span>
                  </div>
                  {r.progress !== null && <ProgressTrack progress={r.progress} status={r.status} className="mt-2" />}
                </div>
                <div className="w-16 text-right">
                  <div className={cn("num font-light leading-none", statusText[r.status], large ? "text-3xl" : "text-xl")}>
                    {label.value}
                  </div>
                  <div className="mt-1 text-[10px] text-muted-foreground">{label.unit}</div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
