// Test stand-in for the build-time "virtual:pwa-register" module.
export function registerSW() {
  return async () => {};
}
