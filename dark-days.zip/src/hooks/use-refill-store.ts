import { useCallback, useEffect, useState } from "react";
import {
  applyDraft,
  createItem,
  loadItems,
  logRefill,
  saveItems,
  todayISO,
  type ISODate,
  type ItemDraft,
  type RefillItem,
} from "@/lib/refill";

/** Local-only store backed by localStorage. Loads after mount so prerendered HTML hydrates cleanly. */
export function useRefillStore() {
  const [items, setItems] = useState<RefillItem[]>([]);
  const [ready, setReady] = useState(false);
  const [today, setToday] = useState<ISODate>("");

  useEffect(() => {
    setItems(loadItems());
    setToday(todayISO());
    setReady(true);

    const refreshDay = () => setToday(todayISO());
    const onStorage = (e: StorageEvent) => {
      if (e.key === null || (e.key.startsWith("dark-days") || e.key.startsWith("dark-refill"))) setItems(loadItems());
    };
    const timer = window.setInterval(refreshDay, 60_000);
    document.addEventListener("visibilitychange", refreshDay);
    window.addEventListener("storage", onStorage);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", refreshDay);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  const commit = useCallback((updater: (prev: RefillItem[]) => RefillItem[]) => {
    setItems((prev) => {
      const next = updater(prev);
      saveItems(next);
      return next;
    });
  }, []);

  const add = useCallback((draft: ItemDraft) => commit((p) => [...p, createItem(draft)]), [commit]);
  const update = useCallback(
    (id: string, draft: ItemDraft) => commit((p) => p.map((i) => (i.id === id ? applyDraft(i, draft) : i))),
    [commit],
  );
  const remove = useCallback((id: string) => commit((p) => p.filter((i) => i.id !== id)), [commit]);
  const refill = useCallback(
    (id: string) => {
      const day = todayISO();
      commit((p) => p.map((i) => (i.id === id ? logRefill(i, day) : i)));
    },
    [commit],
  );
  const restore = useCallback(
    (item: RefillItem) => commit((p) => p.map((i) => (i.id === item.id ? item : i))),
    [commit],
  );
  const replaceAll = useCallback((next: RefillItem[]) => commit(() => next), [commit]);

  return { items, ready, today, add, update, remove, refill, restore, replaceAll };
}
